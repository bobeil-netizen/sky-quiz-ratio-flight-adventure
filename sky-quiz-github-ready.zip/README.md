# Sky Quiz – Ratio Flight Adventure

A browser-based educational game for practising ratios.

## Run locally

**Prerequisites:** Node.js (and npm)

1. Extract or clone this repository.
2. Install dependencies:

   ```bash
   npm install
   ```

3. If the app uses Gemini API features, copy `.env.example` to `.env.local` and add your own `GEMINI_API_KEY`. Never commit a real API key.
4. Start the development server:

   ```bash
   npm run dev
   ```

5. Open the local URL shown in the terminal (the Vite configuration uses port 3000).

## Build

```bash
npm run build
```

The production files will be generated in `dist/`.

## GitHub

Create a new repository on GitHub, then upload these project files or push this folder using Git. Do not upload `node_modules`, `.env.local`, or any real API keys.
